package com.Sesion_05.Reto_01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
