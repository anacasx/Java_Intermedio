package com.Sesion_05.Reto_01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto01Application {

	public static void main(String[] args) {
		SpringApplication.run(Reto01Application.class, args);
	}

}
